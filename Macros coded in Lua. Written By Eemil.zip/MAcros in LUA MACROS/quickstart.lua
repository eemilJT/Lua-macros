--Version 0.1 (Sloppy edition sadly...)
lmc_assign_keyboard('Macro');

-- I know this is so sub-optimal and sloppy but still works
--Made and scripted by EemilMediaGroup
--Please If you can, please code these buttons into this cript: All F_ button, NUMBAD, ARROWS
--(C)2017 For buisness use only

--Script starts here.

lmc_set_handler('Macro',function(button, direction)
  if (direction == 1) then return end  -- ignore down
  if     (button == string.byte('1')) then lmc_spawn ('cmd')--starts cmd what is the main part of this macros thing
  elseif (button == string.byte('5')) then lmc_send_keys("start mums.bat")--dont touch these if you want macros to work
  elseif (button == string.byte('4')) then lmc_send_keys('start run.bat')
  --This is enter to run macros from cmd
  elseif (button == string.byte('3')) then lmc_send_keys ('{ENTER}')
  --types a website adress by pressing number 6
  elseif (button == string.byte('6')) then lmc_send_keys ('youtube.com')
 --You can change these. these are shortcuts to paint dot net program
  elseif (button == string.byte('Q')) then lmc_send_keys ('S')
  elseif (button == string.byte('W')) then lmc_send_keys ('M')
  elseif (button == string.byte('E')) then lmc_send_keys ('B')
  elseif (button == string.byte('R')) then lmc_send_keys ('H')
  elseif (button == string.byte('T')) then lmc_send_keys ('F')
  --starts sony vegas pro 12
  elseif (button == string.byte('2'))  then lmc_send_keys ("start apps.bat")
  --Press P in Lua Macros to see legal information
  elseif (button == string.byte('7')) then lmc_send_keys ('amazon.co.uk')
  elseif (button == string.byte ('P'))  then print ("This code is written by eemil and I dont take any claims if your hardware breaks by my sloppy code sue me if you want but you will lose for lying. This code is written by eemiland I dont have much free time to update this so you have to be happy with elseif buttton=string(blahbalhblah))")
else
                print(' ')
                print('Not yet coded into Lua Macros or will never be, arrow keys,numbad F123456789,10,11,12 etc., wait until next update.  Button number = ' .. button)
	end
  end)

--YES THIS IS IN ALPHA AND SO SLOPPY. Half of this code is based on cmd.


